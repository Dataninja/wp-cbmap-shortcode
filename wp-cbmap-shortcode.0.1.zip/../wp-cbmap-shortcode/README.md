wp-cbmap-shortcode
==================

Plugin wordpress che definisce uno shortcode [cbmap (opzioni)] per includere la mappa in versione embed o widget in un blog Wordpress.
