#!/bin/bash
zip -r wp-cbmap-shortcode.0.1.zip ../wp-cbmap-shortcode/ -x@exclude.lst
